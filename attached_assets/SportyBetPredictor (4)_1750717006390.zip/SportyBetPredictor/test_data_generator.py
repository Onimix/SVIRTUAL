#!/usr/bin/env python3
"""
Generate sample match data for testing the prediction system
"""

import json
import random
from datetime import datetime, timedelta
from data.data_manager import DataManager, Match

def generate_sample_data():
    """Generate realistic sample match data"""
    
    # Virtual football team names (realistic sounding)
    teams = [
        "Arsenal", "Chelsea", "Manchester United", "Liverpool", "Manchester City",
        "Barcelona", "Real Madrid", "Bayern Munich", "PSG", "Juventus",
        "AC Milan", "Inter Milan", "Atletico Madrid", "Valencia", "Sevilla",
        "Borussia Dortmund", "Ajax", "Porto", "Benfica", "Lyon"
    ]
    
    data_manager = DataManager()
    
    # Generate 100 sample matches over the past 30 days
    base_time = datetime.now() - timedelta(days=30)
    
    print("🎲 Generating sample match data...")
    
    for i in range(100):
        # Random teams
        home_team = random.choice(teams)
        away_team = random.choice([t for t in teams if t != home_team])
        
        # Generate realistic scores (favor lower scores, occasional high scores)
        score_weights = [0.3, 0.25, 0.2, 0.15, 0.07, 0.03]  # 0, 1, 2, 3, 4, 5+ goals
        
        home_score = random.choices(range(6), weights=score_weights)[0]
        away_score = random.choices(range(6), weights=score_weights)[0]
        
        # Add some home advantage (slight bias towards home wins)
        if random.random() < 0.15:  # 15% chance to add home advantage
            home_score += 1
        
        # Determine result
        if home_score > away_score:
            result = "1"  # Home win
        elif home_score < away_score:
            result = "2"  # Away win
        else:
            result = "X"  # Draw
        
        # Random timestamp within the past 30 days
        match_time = base_time + timedelta(
            days=random.randint(0, 30),
            hours=random.randint(0, 23),
            minutes=random.randint(0, 59)
        )
        
        # Create match
        match = Match(
            match_id=f"VF_{i+1:04d}",
            home_team=home_team,
            away_team=away_team,
            home_score=home_score,
            away_score=away_score,
            result=result,
            timestamp=match_time.isoformat(),
            league="Virtual Football"
        )
        
        # Add to database
        data_manager.add_match(match)
        
        if (i + 1) % 20 == 0:
            print(f"  Generated {i + 1}/100 matches...")
    
    print("✅ Sample data generation complete!")
    
    # Show statistics
    stats = data_manager.get_database_stats()
    print(f"\n📊 Database Statistics:")
    print(f"  Total matches: {stats['total_matches']}")
    print(f"  Total teams: {stats['total_teams']}")
    
    # Show some sample matches
    recent = data_manager.get_recent_matches(5)
    print(f"\n⚽ Recent matches:")
    for match in recent:
        result_emoji = {"1": "🏆", "X": "🤝", "2": "🏆"}
        print(f"  {match.home_team} {match.home_score}-{match.away_score} {match.away_team} {result_emoji[match.result]}")

if __name__ == "__main__":
    generate_sample_data()