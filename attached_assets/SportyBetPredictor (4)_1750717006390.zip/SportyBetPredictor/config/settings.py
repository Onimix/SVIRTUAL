"""
Configuration settings for the Virtual Football Bot
"""

import os
from typing import Dict, Any

class Config:
    """Configuration class for the bot"""
    
    def __init__(self):
        # Telegram Bot Configuration
        self.TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
        
        # SportyBet WebSocket Configuration  
        self.SPORTYBET_WS_URL = os.getenv(
            "SPORTYBET_WS_URL", 
            "wss://alive-ng.on.sportybet2.com/socket.io/?EIO=3&transport=websocket"
        )
        
        # Data Storage Configuration
        self.DATA_DIR = "data_storage"
        self.MATCHES_FILE = f"{self.DATA_DIR}/matches.json"
        self.STATS_FILE = f"{self.DATA_DIR}/stats.json"
        
        # Prediction Configuration
        self.MIN_MATCHES_FOR_PREDICTION = 10
        self.CONFIDENCE_THRESHOLD = 0.6
        self.MAX_PREDICTIONS_PER_COMMAND = 5
        
        # WebSocket Configuration
        self.WS_RECONNECT_DELAY = 5  # seconds
        self.WS_MAX_RECONNECT_ATTEMPTS = 10
        self.WS_PING_INTERVAL = 30  # seconds
        
        # Bot Configuration
        self.MAX_MESSAGE_LENGTH = 4096
        self.ADMIN_USER_IDS = self._parse_admin_ids()
        
    def _parse_admin_ids(self) -> list:
        """Parse admin user IDs from environment variable"""
        admin_ids_str = os.getenv("ADMIN_USER_IDS", "")
        if not admin_ids_str:
            return []
            
        try:
            return [int(uid.strip()) for uid in admin_ids_str.split(",") if uid.strip()]
        except ValueError:
            return []
    
    def get_websocket_headers(self) -> Dict[str, str]:
        """Get headers for WebSocket connection"""
        return {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Origin": "https://www.sportybet.com",
            "Referer": "https://www.sportybet.com/",
        }
    
    def validate(self) -> bool:
        """Validate configuration"""
        if not self.TELEGRAM_BOT_TOKEN:
            raise ValueError("TELEGRAM_BOT_TOKEN is required")
            
        if not self.SPORTYBET_WS_URL:
            raise ValueError("SPORTYBET_WS_URL is required")
            
        return True
