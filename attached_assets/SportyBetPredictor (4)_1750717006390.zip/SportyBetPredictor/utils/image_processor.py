"""
Image processing for extracting match information from screenshots
"""

import re
import cv2
import numpy as np
import pytesseract
from PIL import Image
from typing import List, Tuple, Optional
from utils.logger import setup_logger

logger = setup_logger(__name__)

class ImageProcessor:
    """Process screenshots to extract match information"""
    
    def __init__(self):
        # Configure tesseract if needed
        # pytesseract.pytesseract.tesseract_cmd = r'/usr/bin/tesseract'  # Adjust path if needed
        pass
    
    def extract_matches_from_image(self, image_path: str) -> List[Tuple[str, str]]:
        """
        Extract match pairs from screenshot
        
        Args:
            image_path: Path to the screenshot
            
        Returns:
            List of (home_team, away_team) tuples
        """
        try:
            # Load and preprocess image
            image = cv2.imread(image_path)
            if image is None:
                logger.error(f"Could not load image: {image_path}")
                return []
            
            # Convert to PIL Image for tesseract
            pil_image = Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
            
            # Extract text using OCR
            extracted_text = pytesseract.image_to_string(pil_image, config='--psm 6')
            logger.info(f"Extracted text from image: {extracted_text[:200]}...")
            
            # Parse matches from text
            matches = self._parse_matches_from_text(extracted_text)
            
            return matches
            
        except Exception as e:
            logger.error(f"Error processing image: {e}")
            return []
    
    def extract_matches_from_bytes(self, image_bytes: bytes) -> List[Tuple[str, str]]:
        """
        Extract match pairs from image bytes (from Telegram)
        
        Args:
            image_bytes: Image data as bytes
            
        Returns:
            List of (home_team, away_team) tuples
        """
        try:
            # Convert bytes to numpy array
            nparr = np.frombuffer(image_bytes, np.uint8)
            image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            if image is None:
                logger.error("Could not decode image from bytes")
                return []
            
            # Preprocess image for better OCR
            processed_image = self._preprocess_image(image)
            
            # Convert to PIL Image for tesseract
            pil_image = Image.fromarray(cv2.cvtColor(processed_image, cv2.COLOR_BGR2RGB))
            
            # Extract text using OCR
            extracted_text = pytesseract.image_to_string(pil_image, config='--psm 6')
            logger.info(f"Extracted text from image: {extracted_text[:200]}...")
            
            # Parse matches from text
            matches = self._parse_matches_from_text(extracted_text)
            
            return matches
            
        except Exception as e:
            logger.error(f"Error processing image bytes: {e}")
            return []
    
    def _preprocess_image(self, image):
        """Preprocess image for better OCR results"""
        try:
            # Convert to grayscale
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            
            # Apply Gaussian blur to reduce noise
            blurred = cv2.GaussianBlur(gray, (5, 5), 0)
            
            # Apply threshold to get binary image
            _, thresh = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            
            # Convert back to BGR for PIL
            return cv2.cvtColor(thresh, cv2.COLOR_GRAY2BGR)
            
        except Exception as e:
            logger.error(f"Error preprocessing image: {e}")
            return image
    
    def _parse_matches_from_text(self, text: str) -> List[Tuple[str, str]]:
        """Parse match information from extracted text"""
        try:
            matches = []
            lines = text.split('\n')
            
            # Common patterns for match listings
            patterns = [
                r'([A-Za-z\s]+)\s+vs?\s+([A-Za-z\s]+)',  # Team1 vs Team2
                r'([A-Za-z\s]+)\s+-\s+([A-Za-z\s]+)',    # Team1 - Team2
                r'([A-Za-z\s]+)\s+v\s+([A-Za-z\s]+)',    # Team1 v Team2
                r'([A-Za-z\s]+)\s+@\s+([A-Za-z\s]+)',    # Team1 @ Team2
            ]
            
            for line in lines:
                line = line.strip()
                if len(line) < 5:  # Skip very short lines
                    continue
                
                for pattern in patterns:
                    matches_found = re.findall(pattern, line, re.IGNORECASE)
                    for match in matches_found:
                        home_team = self._clean_team_name(match[0])
                        away_team = self._clean_team_name(match[1])
                        
                        # Validate team names
                        if self._is_valid_team_name(home_team) and self._is_valid_team_name(away_team):
                            matches.append((home_team, away_team))
            
            # Remove duplicates while preserving order
            unique_matches = []
            seen = set()
            for match in matches:
                match_key = (match[0].lower(), match[1].lower())
                if match_key not in seen:
                    seen.add(match_key)
                    unique_matches.append(match)
            
            logger.info(f"Parsed {len(unique_matches)} matches from text")
            return unique_matches
            
        except Exception as e:
            logger.error(f"Error parsing matches from text: {e}")
            return []
    
    def _clean_team_name(self, team_name: str) -> str:
        """Clean and standardize team name"""
        try:
            # Remove extra whitespace and common OCR artifacts
            cleaned = re.sub(r'\s+', ' ', team_name.strip())
            
            # Remove common OCR errors
            cleaned = re.sub(r'[^\w\s]', '', cleaned)
            
            # Capitalize properly
            cleaned = cleaned.title()
            
            return cleaned
            
        except Exception as e:
            logger.error(f"Error cleaning team name '{team_name}': {e}")
            return team_name
    
    def _is_valid_team_name(self, team_name: str) -> bool:
        """Validate if the extracted text looks like a valid team name"""
        try:
            # Basic validation rules
            if len(team_name) < 2 or len(team_name) > 30:
                return False
            
            # Should contain mostly letters
            letter_count = sum(1 for c in team_name if c.isalpha())
            if letter_count < len(team_name) * 0.7:
                return False
            
            # Common invalid patterns
            invalid_patterns = [
                r'^\d+$',  # Only numbers
                r'^[^a-zA-Z]+$',  # No letters
                r'(match|game|vs|versus|time|score)',  # Common non-team words
            ]
            
            for pattern in invalid_patterns:
                if re.search(pattern, team_name, re.IGNORECASE):
                    return False
            
            return True
            
        except Exception as e:
            logger.error(f"Error validating team name '{team_name}': {e}")
            return False