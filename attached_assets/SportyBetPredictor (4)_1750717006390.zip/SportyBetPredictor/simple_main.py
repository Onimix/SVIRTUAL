#!/usr/bin/env python3
"""
Simplified main entry point that fixes the async event loop issues
"""

import asyncio
import threading
import time
import signal
import sys
from utils.logger import setup_logger
from ws_client.sportybet_client import SportyBetWebSocketClient
from config.settings import Config
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters
from telegram import Update
from telegram.ext import ContextTypes
from data.data_manager import DataManager
from prediction.analyzer import PredictionAnalyzer
from utils.image_processor import ImageProcessor
import io

# Setup logging
logger = setup_logger(__name__)

# Global instances
data_manager = DataManager()
analyzer = PredictionAnalyzer()
image_processor = ImageProcessor()
websocket_client = None

# Bot command handlers
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /start command"""
    welcome_message = """
🏆 **Virtual Football Prediction Bot** ⚽

Welcome! I analyze SportyBet virtual football matches and provide predictions.

**Available Commands:**
/predict - Predict a single match (e.g., /predict Arsenal vs Chelsea)
/predict_multi - Predict multiple matches
/stats - View database statistics
/teams - List all available teams
/top - Get top predictions
/status - Check bot status
/help - Show help

Let's start predicting!
    """
    await update.message.reply_text(welcome_message)

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /help command"""
    help_text = """
**Command Guide:**

• /predict Team1 vs Team2 - Predict single match
• /predict_multi Team1 vs Team2, Team3 vs Team4 - Multiple matches
• /stats - Database statistics
• /teams - List available teams
• /top - Top predictions
• /status - Bot status

**Tips:**
• Use exact team names
• Higher confidence = more reliable
• Predictions improve with more data
    """
    await update.message.reply_text(help_text)

async def predict_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /predict command"""
    try:
        if not context.args:
            await update.message.reply_text(
                "Usage: /predict Team1 vs Team2\nExample: /predict Arsenal vs Chelsea"
            )
            return
        
        # Parse team names
        match_text = " ".join(context.args).lower()
        if " vs " not in match_text and " v " not in match_text:
            await update.message.reply_text(
                "Invalid format! Use: /predict Team1 vs Team2"
            )
            return
        
        # Split teams
        if " vs " in match_text:
            teams = match_text.split(" vs ")
        else:
            teams = match_text.split(" v ")
        
        if len(teams) != 2:
            await update.message.reply_text("Please specify exactly two teams")
            return
        
        home_team = teams[0].strip().title()
        away_team = teams[1].strip().title()
        
        # Show processing
        processing_msg = await update.message.reply_text(
            f"🔍 Analyzing: {home_team} vs {away_team}..."
        )
        
        # Get prediction
        prediction = analyzer.predict_match(home_team, away_team)
        
        if prediction.get('error'):
            result = f"❌ Error: {prediction['error']}"
        elif prediction.get('prediction'):
            confidence = prediction.get('confidence', 0)
            pred_map = {"1": "Home Win", "X": "Draw", "2": "Away Win"}
            pred_text = pred_map.get(prediction['prediction'], 'Unknown')
            
            result = f"""
🎯 **Prediction: {home_team} vs {away_team}**

**Result:** {pred_text}
**Confidence:** {confidence:.1%}

**Probabilities:**
• Home Win: {prediction.get('probabilities', {}).get('home_win', 0):.1%}
• Draw: {prediction.get('probabilities', {}).get('draw', 0):.1%}
• Away Win: {prediction.get('probabilities', {}).get('away_win', 0):.1%}

**Data Quality:**
• Home matches: {prediction.get('data_quality', {}).get('home_matches', 0)}
• Away matches: {prediction.get('data_quality', {}).get('away_matches', 0)}
            """
        else:
            result = "❌ Unable to generate prediction. Insufficient data."
        
        await processing_msg.edit_text(result)
        
    except Exception as e:
        logger.error(f"Error in predict command: {e}")
        await update.message.reply_text(f"❌ Error: {str(e)}")

async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /stats command"""
    try:
        db_stats = data_manager.get_database_stats()
        recent_matches = data_manager.get_recent_matches(5)
        
        stats_text = f"""
📊 **Database Statistics**

**Data:**
• Total Matches: {db_stats.get('total_matches', 0)}
• Total Teams: {db_stats.get('total_teams', 0)}

**Recent Matches:**
"""
        
        if recent_matches:
            for match in recent_matches:
                stats_text += f"• {match.home_team} {match.home_score}-{match.away_score} {match.away_team}\n"
        else:
            stats_text += "• No matches yet - bot is collecting data\n"
        
        await update.message.reply_text(stats_text)
        
    except Exception as e:
        await update.message.reply_text(f"❌ Error getting stats: {str(e)}")

async def teams_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /teams command"""
    try:
        teams = data_manager.get_all_teams()
        
        if not teams:
            await update.message.reply_text(
                "📋 No teams available yet.\nThe bot is collecting data from SportyBet."
            )
            return
        
        teams.sort()
        teams_text = f"📋 **Available Teams ({len(teams)}):**\n\n"
        
        for i, team in enumerate(teams[:15], 1):  # Limit to 15 teams
            teams_text += f"{i}. {team}\n"
        
        if len(teams) > 15:
            teams_text += f"\n... and {len(teams) - 15} more teams"
        
        await update.message.reply_text(teams_text)
        
    except Exception as e:
        await update.message.reply_text(f"❌ Error getting teams: {str(e)}")

async def status_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /status command"""
    try:
        ws_status = websocket_client.get_connection_status() if websocket_client else {"connected": False}
        db_stats = data_manager.get_database_stats()
        
        status_text = f"""
🔧 **Bot Status**

**WebSocket:** {'✅ Connected' if ws_status.get('connected') else '❌ Disconnected'}
**Database:** {db_stats.get('total_matches', 0)} matches stored
**Teams:** {db_stats.get('total_teams', 0)} teams tracked

**System:** ✅ Running
        """
        
        await update.message.reply_text(status_text)
        
    except Exception as e:
        await update.message.reply_text(f"❌ Error getting status: {str(e)}")

async def results_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /results command to view all stored match results"""
    try:
        # Get number of results to show (default 20)
        limit = 20
        if context.args and context.args[0].isdigit():
            limit = min(int(context.args[0]), 50)  # Max 50 results
        
        recent_matches = data_manager.get_recent_matches(limit)
        
        if not recent_matches:
            await update.message.reply_text(
                "📋 No match results stored yet.\nThe bot is still collecting data from SportyBet."
            )
            return
        
        results_text = f"📋 **Recent Match Results ({len(recent_matches)}):**\n\n"
        
        for i, match in enumerate(recent_matches, 1):
            result_emoji = {"1": "🏆", "X": "🤝", "2": "🏆"}
            date_str = match.timestamp[:10] if len(match.timestamp) >= 10 else "Unknown"
            
            results_text += f"{i}. **{match.home_team}** {match.home_score}-{match.away_score} **{match.away_team}** {result_emoji.get(match.result, '⚽')}\n"
            results_text += f"   📅 {date_str} | ID: {match.match_id}\n\n"
        
        if len(recent_matches) == limit:
            results_text += f"\nShowing last {limit} results. Use `/results [number]` for more (max 50)."
        
        await update.message.reply_text(results_text)
        
    except Exception as e:
        await update.message.reply_text(f"❌ Error getting results: {str(e)}")

async def predict_from_image(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle image messages for multiple match prediction"""
    try:
        # Check if message has photo
        if not update.message.photo:
            await update.message.reply_text(
                "📸 Please send a screenshot containing match listings.\n"
                "I'll extract the matches and provide predictions for all of them."
            )
            return
        
        await update.message.reply_text("🔍 Processing screenshot...")
        
        # Get the largest photo
        photo = update.message.photo[-1]
        
        # Download photo
        photo_file = await photo.get_file()
        photo_bytes = await photo_file.download_as_bytearray()
        
        # Extract matches from image
        matches = image_processor.extract_matches_from_bytes(bytes(photo_bytes))
        
        if not matches:
            await update.message.reply_text(
                "❌ Could not extract any matches from the screenshot.\n\n"
                "Tips for better results:\n"
                "• Ensure text is clear and readable\n"
                "• Use good lighting\n"
                "• Include team names in format 'Team1 vs Team2'\n"
                "• Avoid blurry or distorted images"
            )
            return
        
        # Limit number of matches to process
        if len(matches) > 10:
            matches = matches[:10]
            await update.message.reply_text(
                f"📸 Extracted {len(matches)} matches (showing first 10):"
            )
        else:
            await update.message.reply_text(f"📸 Extracted {len(matches)} matches:")
        
        # Show extracted matches
        matches_text = "\n".join([f"• {home} vs {away}" for home, away in matches])
        await update.message.reply_text(matches_text)
        
        # Generate predictions for all matches
        await update.message.reply_text("🎯 Generating predictions...")
        
        predictions = analyzer.predict_multiple_matches(matches)
        
        # Format results
        results_text = "🎯 **Predictions from Screenshot:**\n\n"
        
        for i, prediction in enumerate(predictions, 1):
            match_name = prediction.get('match', 'Unknown Match')
            
            if prediction.get('error'):
                results_text += f"{i}. **{match_name}**\n"
                results_text += f"   ❌ {prediction['error']}\n\n"
                continue
            
            pred_map = {"1": "Home Win", "X": "Draw", "2": "Away Win"}
            pred_text = pred_map.get(prediction.get('prediction'), 'Unknown')
            confidence = prediction.get('confidence', 0)
            
            results_text += f"{i}. **{match_name}**\n"
            results_text += f"   🎯 **{pred_text}** ({confidence:.1%} confidence)\n"
            
            probs = prediction.get('probabilities', {})
            results_text += f"   📊 Home: {probs.get('home_win', 0):.0%} | "
            results_text += f"Draw: {probs.get('draw', 0):.0%} | "
            results_text += f"Away: {probs.get('away_win', 0):.0%}\n\n"
        
        # Send results (split if too long)
        if len(results_text) > 4000:
            # Split into chunks
            chunks = []
            current_chunk = "🎯 **Predictions from Screenshot:**\n\n"
            
            for i, prediction in enumerate(predictions, 1):
                match_name = prediction.get('match', 'Unknown Match')
                
                chunk_text = f"{i}. **{match_name}**\n"
                if prediction.get('error'):
                    chunk_text += f"   ❌ {prediction['error']}\n\n"
                else:
                    pred_map = {"1": "Home Win", "X": "Draw", "2": "Away Win"}
                    pred_text = pred_map.get(prediction.get('prediction'), 'Unknown')
                    confidence = prediction.get('confidence', 0)
                    chunk_text += f"   🎯 **{pred_text}** ({confidence:.1%})\n\n"
                
                if len(current_chunk + chunk_text) > 3500:
                    chunks.append(current_chunk)
                    current_chunk = chunk_text
                else:
                    current_chunk += chunk_text
            
            if current_chunk:
                chunks.append(current_chunk)
            
            for chunk in chunks:
                await update.message.reply_text(chunk)
        else:
            await update.message.reply_text(results_text)
        
    except Exception as e:
        logger.error(f"Error processing image: {e}")
        await update.message.reply_text(f"❌ Error processing image: {str(e)}")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle regular messages and photos"""
    try:
        if update.message.photo:
            await predict_from_image(update, context)
        else:
            await update.message.reply_text(
                "Send me a screenshot of match listings for predictions, or use these commands:\n\n"
                "• /predict Team1 vs Team2\n"
                "• /stats - Database statistics\n"
                "• /results - View stored results\n"
                "• /teams - Available teams\n"
                "• /help - Full command list"
            )
    except Exception as e:
        logger.error(f"Error handling message: {e}")
        await update.message.reply_text("❌ Error processing message")

def start_websocket():
    """Start WebSocket in separate thread"""
    global websocket_client
    try:
        websocket_client = SportyBetWebSocketClient()
        websocket_client.start()
    except Exception as e:
        logger.error(f"WebSocket error: {e}")

def main():
    """Main function"""
    try:
        # Setup configuration
        config = Config()
        config.validate()
        
        logger.info("🚀 Starting Virtual Football Prediction Bot...")
        
        # Start WebSocket in background thread
        ws_thread = threading.Thread(target=start_websocket, daemon=True)
        ws_thread.start()
        
        # Give WebSocket time to connect
        time.sleep(3)
        
        # Create Telegram application
        logger.info("🤖 Starting Telegram bot...")
        app = Application.builder().token(config.TELEGRAM_BOT_TOKEN).build()
        
        # Add handlers
        app.add_handler(CommandHandler("start", start_command))
        app.add_handler(CommandHandler("help", help_command))
        app.add_handler(CommandHandler("predict", predict_command))
        app.add_handler(CommandHandler("stats", stats_command))
        app.add_handler(CommandHandler("teams", teams_command))
        app.add_handler(CommandHandler("status", status_command))
        
        # Start polling
        logger.info("✅ Bot ready! Starting polling...")
        app.run_polling(drop_pending_updates=True)
        
    except KeyboardInterrupt:
        logger.info("👋 Bot stopped by user")
    except Exception as e:
        logger.error(f"❌ Fatal error: {e}")

if __name__ == "__main__":
    main()