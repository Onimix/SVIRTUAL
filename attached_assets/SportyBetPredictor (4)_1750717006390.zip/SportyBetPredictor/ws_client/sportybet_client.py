"""
WebSocket client for connecting to SportyBet virtual football data
"""

import json
import threading
import time
import websocket
from typing import Dict, Any, Optional, Callable
from datetime import datetime
from utils.logger import setup_logger
from data.data_manager import DataManager, Match
from config.settings import Config

logger = setup_logger(__name__)

class SportyBetWebSocketClient:
    """WebSocket client for SportyBet virtual football data"""
    
    def __init__(self):
        self.config = Config()
        self.data_manager = DataManager()
        self.ws = None
        self.running = False
        self.reconnect_count = 0
        self.last_ping = time.time()
        
        # Callbacks for different message types
        self.message_handlers: Dict[str, Callable] = {
            'match_result': self._handle_match_result,
            'match_start': self._handle_match_start,
            'live_score': self._handle_live_score,
        }
        
    def start(self):
        """Start the WebSocket connection"""
        self.running = True
        self._connect()
        
    def stop(self):
        """Stop the WebSocket connection"""
        logger.info("🛑 Stopping WebSocket client...")
        self.running = False
        
        if self.ws:
            self.ws.close()
            
    def _connect(self):
        """Establish WebSocket connection"""
        while self.running and self.reconnect_count < self.config.WS_MAX_RECONNECT_ATTEMPTS:
            try:
                logger.info(f"🔌 Connecting to SportyBet WebSocket... (Attempt {self.reconnect_count + 1})")
                
                # Create WebSocket connection
                self.ws = websocket.WebSocketApp(
                    self.config.SPORTYBET_WS_URL,
                    header=self.config.get_websocket_headers(),
                    on_open=self._on_open,
                    on_message=self._on_message,
                    on_error=self._on_error,
                    on_close=self._on_close
                )
                
                # Start connection
                self.ws.run_forever()
                
            except Exception as e:
                logger.error(f"❌ WebSocket connection failed: {e}")
                self.reconnect_count += 1
                
                if self.running and self.reconnect_count < self.config.WS_MAX_RECONNECT_ATTEMPTS:
                    wait_time = min(self.config.WS_RECONNECT_DELAY * self.reconnect_count, 60)
                    logger.info(f"⏳ Reconnecting in {wait_time} seconds...")
                    time.sleep(wait_time)
                else:
                    logger.error("🔴 Max reconnection attempts reached")
                    break
    
    def _on_open(self, ws):
        """Handle WebSocket connection open"""
        logger.info("✅ WebSocket connection established")
        self.reconnect_count = 0
        self.last_ping = time.time()
        
        # Subscribe to virtual football events
        self._subscribe_to_virtual_football()
        
        # Start ping thread
        ping_thread = threading.Thread(target=self._ping_loop, daemon=True)
        ping_thread.start()
    
    def _on_message(self, ws, message):
        """Handle incoming WebSocket messages"""
        try:
            # Handle Socket.IO protocol messages (like from your original code)
            if message.startswith("42"):
                # Remove the '42' prefix and parse JSON array
                payload = message[2:]
                data = json.loads(payload)
                
                if isinstance(data, list) and len(data) >= 2:
                    event = data[0]
                    content = data[1]
                    
                    logger.debug(f"📨 Socket.IO event: {event}, content: {content}")
                    
                    # Check for virtual football result event
                    if event == "vFootballResult" or "result" in str(event).lower():
                        self._handle_socketio_match_result(content)
                    else:
                        # Try to extract any match info from the content
                        self._try_extract_match_info(content)
                        
            elif message.startswith(("0", "1", "2", "3", "4")):
                # Other Socket.IO message types - just log for now
                logger.debug(f"📨 Socket.IO message: {message[:100]}...")
                
            else:
                # Try regular JSON parsing
                data = json.loads(message)
                logger.debug(f"📨 Received JSON message: {data}")
                self._process_message(data)
            
        except json.JSONDecodeError as e:
            logger.debug(f"Non-JSON message received: {message[:100]}...")
        except Exception as e:
            logger.error(f"❌ Error processing message: {e}")
            logger.debug(f"Raw message: {message[:200]}...")
    
    def _on_error(self, ws, error):
        """Handle WebSocket errors"""
        logger.error(f"🔴 WebSocket error: {error}")
    
    def _on_close(self, ws, close_status_code, close_msg):
        """Handle WebSocket connection close"""
        logger.warning(f"🔌 WebSocket connection closed: {close_status_code} - {close_msg}")
        
        # Attempt to reconnect if still running
        if self.running:
            logger.info("🔄 Attempting to reconnect...")
            threading.Thread(target=self._connect, daemon=True).start()
    
    def _subscribe_to_virtual_football(self):
        """Subscribe to virtual football events"""
        try:
            # Send subscription message for virtual football
            subscription_message = {
                "action": "subscribe",
                "channel": "virtual_football",
                "sport_id": "virtual_football",
                "market_types": ["1x2", "over_under", "both_teams_score"]
            }
            
            if self.ws:
                self.ws.send(json.dumps(subscription_message))
                logger.info("📡 Subscribed to virtual football events")
                
        except Exception as e:
            logger.error(f"❌ Failed to subscribe to virtual football: {e}")
    
    def _ping_loop(self):
        """Send periodic ping messages to keep connection alive"""
        while self.running and self.ws:
            try:
                current_time = time.time()
                
                if current_time - self.last_ping > self.config.WS_PING_INTERVAL:
                    ping_message = {
                        "action": "ping",
                        "timestamp": int(current_time * 1000)
                    }
                    
                    self.ws.send(json.dumps(ping_message))
                    self.last_ping = current_time
                    logger.debug("🏓 Sent ping message")
                
                time.sleep(10)  # Check every 10 seconds
                
            except Exception as e:
                logger.error(f"❌ Error in ping loop: {e}")
                break
    
    def _process_message(self, data: Dict[str, Any]):
        """Process different types of messages"""
        try:
            message_type = data.get('type', '').lower()
            
            # Handle different message types
            if message_type == 'match_result':
                self._handle_match_result(data)
            elif message_type == 'match_start':
                self._handle_match_start(data)
            elif message_type == 'live_score':
                self._handle_live_score(data)
            elif message_type == 'pong':
                logger.debug("🏓 Received pong")
            elif 'match' in data and 'result' in data:
                # Alternative format for match results
                self._handle_alternative_match_result(data)
            else:
                # Try to extract match information from any message
                self._try_extract_match_info(data)
                
        except Exception as e:
            logger.error(f"❌ Error processing message type {data.get('type', 'unknown')}: {e}")
    
    def _handle_match_result(self, data: Dict[str, Any]):
        """Handle match result messages"""
        try:
            match_info = data.get('match', {})
            
            # Extract match details
            match_id = match_info.get('id') or match_info.get('match_id', '')
            home_team = match_info.get('home_team', {}).get('name', 'Unknown')
            away_team = match_info.get('away_team', {}).get('name', 'Unknown')
            
            # Extract scores
            score = match_info.get('score', {})
            home_score = int(score.get('home', 0))
            away_score = int(score.get('away', 0))
            
            # Determine result
            if home_score > away_score:
                result = "1"  # Home win
            elif home_score < away_score:
                result = "2"  # Away win
            else:
                result = "X"  # Draw
            
            # Create match object
            match = Match(
                match_id=str(match_id),
                home_team=home_team,
                away_team=away_team,
                home_score=home_score,
                away_score=away_score,
                result=result,
                timestamp=datetime.now().isoformat(),
                league="Virtual Football"
            )
            
            # Store match result
            if self.data_manager.add_match(match):
                logger.info(f"⚽ Match result: {home_team} {home_score}-{away_score} {away_team} ({result})")
            
        except Exception as e:
            logger.error(f"❌ Error handling match result: {e}")
            logger.debug(f"Match result data: {data}")
    
    def _handle_match_start(self, data: Dict[str, Any]):
        """Handle match start messages"""
        try:
            match_info = data.get('match', {})
            home_team = match_info.get('home_team', {}).get('name', 'Unknown')
            away_team = match_info.get('away_team', {}).get('name', 'Unknown')
            
            logger.info(f"🏟️ Match starting: {home_team} vs {away_team}")
            
        except Exception as e:
            logger.error(f"❌ Error handling match start: {e}")
    
    def _handle_live_score(self, data: Dict[str, Any]):
        """Handle live score updates"""
        try:
            match_info = data.get('match', {})
            score = match_info.get('score', {})
            
            home_team = match_info.get('home_team', {}).get('name', 'Unknown')
            away_team = match_info.get('away_team', {}).get('name', 'Unknown')
            home_score = score.get('home', 0)
            away_score = score.get('away', 0)
            
            logger.debug(f"📊 Live score: {home_team} {home_score}-{away_score} {away_team}")
            
        except Exception as e:
            logger.error(f"❌ Error handling live score: {e}")
    
    def _handle_alternative_match_result(self, data: Dict[str, Any]):
        """Handle alternative format for match results"""
        try:
            # Extract match information from alternative format
            match_id = str(data.get('id', '')) or str(data.get('match_id', ''))
            
            # Try different possible field names
            home_team = (data.get('home') or data.get('home_team') or 
                        data.get('team1') or {}).get('name', 'Unknown')
            away_team = (data.get('away') or data.get('away_team') or 
                        data.get('team2') or {}).get('name', 'Unknown')
            
            # Extract result
            result_data = data.get('result', {})
            home_score = int(result_data.get('home_score', 0))
            away_score = int(result_data.get('away_score', 0))
            
            # Determine match result
            if home_score > away_score:
                result = "1"
            elif home_score < away_score:
                result = "2"
            else:
                result = "X"
            
            # Create and store match
            match = Match(
                match_id=match_id,
                home_team=home_team,
                away_team=away_team,
                home_score=home_score,
                away_score=away_score,
                result=result,
                timestamp=datetime.now().isoformat(),
                league="Virtual Football"
            )
            
            if self.data_manager.add_match(match):
                logger.info(f"⚽ Alternative match result: {home_team} {home_score}-{away_score} {away_team}")
                
        except Exception as e:
            logger.error(f"❌ Error handling alternative match result: {e}")
    
    def _handle_socketio_match_result(self, content: Dict[str, Any]):
        """Handle Socket.IO formatted match results"""
        try:
            logger.info(f"🏈 Processing Socket.IO match result: {content}")
            
            # Try to extract match details from the content
            # Adapt these field names based on actual SportyBet message format
            match_id = str(content.get("match_id", content.get("id", int(time.time()))))
            
            # Extract team names - adapt field names as needed
            home_team = content.get("home_team", content.get("home", "Unknown"))
            away_team = content.get("away_team", content.get("away", "Unknown"))
            
            # Extract scores - adapt based on actual format
            if "score" in content:
                score_str = content["score"]
                if isinstance(score_str, str) and "-" in score_str:
                    home_score, away_score = map(int, score_str.split("-"))
                else:
                    home_score = int(content.get("home_score", 0))
                    away_score = int(content.get("away_score", 0))
            else:
                home_score = int(content.get("home_score", 0))
                away_score = int(content.get("away_score", 0))
            
            # Determine result
            if home_score > away_score:
                result = "1"  # Home win
            elif home_score < away_score:
                result = "2"  # Away win
            else:
                result = "X"  # Draw
            
            # Create match object
            match = Match(
                match_id=match_id,
                home_team=str(home_team),
                away_team=str(away_team),
                home_score=home_score,
                away_score=away_score,
                result=result,
                timestamp=datetime.now().isoformat(),
                league="Virtual Football"
            )
            
            # Store the match
            if self.data_manager.add_match(match):
                logger.info(f"⚽ Socket.IO match added: {home_team} {home_score}-{away_score} {away_team}")
            
        except Exception as e:
            logger.error(f"❌ Error handling Socket.IO match result: {e}")
            logger.debug(f"Content was: {content}")

    def _try_extract_match_info(self, data: Dict[str, Any]):
        """Try to extract match information from any message format"""
        try:
            # Look for common patterns in the data
            if ('teams' in data or 'score' in data or 
                'home' in data or 'away' in data):
                
                logger.debug(f"🔍 Potential match data found: {data}")
                
                # Try to extract basic info
                match_id = (data.get('id') or data.get('match_id') or 
                           data.get('event_id') or str(int(time.time())))
                
                # This is a fallback - in production, you'd need to understand
                # the exact message format from SportyBet's WebSocket API
                
        except Exception as e:
            logger.debug(f"No match info extracted: {e}")
    
    def get_connection_status(self) -> Dict[str, Any]:
        """Get current connection status"""
        return {
            "connected": self.ws is not None and self.running,
            "reconnect_count": self.reconnect_count,
            "last_ping": datetime.fromtimestamp(self.last_ping).isoformat(),
            "websocket_url": self.config.SPORTYBET_WS_URL
        }
