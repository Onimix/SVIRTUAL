"""
Statistical analysis and prediction algorithms for virtual football matches
"""

import statistics
from collections import defaultdict, Counter
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional, Any
from data.data_manager import DataManager, Match, TeamStats
from utils.logger import setup_logger

logger = setup_logger(__name__)

class PredictionAnalyzer:
    """Analyzes match data and provides predictions"""
    
    def __init__(self):
        self.data_manager = DataManager()
        
    def predict_match(self, home_team: str, away_team: str) -> Dict[str, Any]:
        """
        Predict the outcome of a match between two teams
        
        Args:
            home_team: Home team name
            away_team: Away team name
            
        Returns:
            Dictionary containing prediction details
        """
        try:
            # Get team statistics
            home_stats = self.data_manager.get_team_stats(home_team)
            away_stats = self.data_manager.get_team_stats(away_team)
            
            if not home_stats or not away_stats:
                return {
                    "prediction": None,
                    "confidence": 0.0,
                    "error": f"Insufficient data for teams: {home_team} vs {away_team}"
                }
            
            # Get head-to-head history
            h2h_matches = self.data_manager.get_head_to_head(home_team, away_team, 20)
            
            # Calculate prediction using multiple factors
            prediction_result = self._calculate_match_prediction(
                home_stats, away_stats, h2h_matches, home_team, away_team
            )
            
            return prediction_result
            
        except Exception as e:
            logger.error(f"Error predicting match {home_team} vs {away_team}: {e}")
            return {
                "prediction": None,
                "confidence": 0.0,
                "error": str(e)
            }
    
    def predict_multiple_matches(self, match_pairs: List[Tuple[str, str]]) -> List[Dict[str, Any]]:
        """
        Predict multiple matches
        
        Args:
            match_pairs: List of (home_team, away_team) tuples
            
        Returns:
            List of prediction results
        """
        predictions = []
        
        for home_team, away_team in match_pairs:
            prediction = self.predict_match(home_team, away_team)
            prediction['match'] = f"{home_team} vs {away_team}"
            predictions.append(prediction)
            
        return predictions
    
    def _calculate_match_prediction(
        self, 
        home_stats: TeamStats, 
        away_stats: TeamStats, 
        h2h_matches: List[Match],
        home_team: str,
        away_team: str
    ) -> Dict[str, Any]:
        """Calculate match prediction using statistical analysis"""
        
        # Initialize prediction weights
        home_win_weight = 0.0
        draw_weight = 0.0
        away_win_weight = 0.0
        
        confidence_factors = []
        analysis_details = []
        
        # Factor 1: Overall team performance (40% weight)
        if home_stats.matches_played >= 5 and away_stats.matches_played >= 5:
            home_form = self._calculate_team_form(home_stats)
            away_form = self._calculate_team_form(away_stats)
            
            form_difference = home_form - away_form
            
            if form_difference > 0.1:
                home_win_weight += 0.4 * min(form_difference, 0.5)
                analysis_details.append(f"✅ {home_team} has better overall form ({home_form:.2f} vs {away_form:.2f})")
            elif form_difference < -0.1:
                away_win_weight += 0.4 * min(abs(form_difference), 0.5)
                analysis_details.append(f"✅ {away_team} has better overall form ({away_form:.2f} vs {home_form:.2f})")
            else:
                draw_weight += 0.2
                analysis_details.append("📊 Teams have similar overall form")
                
            confidence_factors.append(0.4)
        
        # Factor 2: Head-to-head record (30% weight)
        if len(h2h_matches) >= 3:
            h2h_analysis = self._analyze_head_to_head(h2h_matches, home_team, away_team)
            
            home_win_weight += 0.3 * h2h_analysis['home_advantage']
            away_win_weight += 0.3 * h2h_analysis['away_advantage']
            draw_weight += 0.3 * h2h_analysis['draw_tendency']
            
            analysis_details.append(f"📈 H2H: {h2h_analysis['summary']}")
            confidence_factors.append(0.3)
        
        # Factor 3: Recent form (20% weight)
        recent_home_form = self._get_recent_form(home_team, 10)
        recent_away_form = self._get_recent_form(away_team, 10)
        
        if recent_home_form and recent_away_form:
            recent_diff = recent_home_form - recent_away_form
            
            if recent_diff > 0.15:
                home_win_weight += 0.2 * min(recent_diff, 0.4)
                analysis_details.append(f"🔥 {home_team} in better recent form")
            elif recent_diff < -0.15:
                away_win_weight += 0.2 * min(abs(recent_diff), 0.4)
                analysis_details.append(f"🔥 {away_team} in better recent form")
            else:
                draw_weight += 0.1
                
            confidence_factors.append(0.2)
        
        # Factor 4: Home advantage (10% weight)
        home_win_weight += 0.1  # Standard home advantage
        analysis_details.append("🏠 Home advantage applied")
        confidence_factors.append(0.1)
        
        # Normalize weights
        total_weight = home_win_weight + draw_weight + away_win_weight
        if total_weight > 0:
            home_win_weight /= total_weight
            draw_weight /= total_weight
            away_win_weight /= total_weight
        
        # Determine prediction
        predictions = {
            "1": home_win_weight,
            "X": draw_weight,
            "2": away_win_weight
        }
        
        predicted_outcome = max(predictions, key=predictions.get)
        confidence = predictions[predicted_outcome]
        
        # Calculate overall confidence based on data availability
        overall_confidence = statistics.mean(confidence_factors) if confidence_factors else 0.0
        overall_confidence = min(confidence * overall_confidence * 2, 1.0)
        
        # Generate recommended bet
        bet_recommendation = self._generate_bet_recommendation(predictions, overall_confidence)
        
        return {
            "prediction": predicted_outcome,
            "confidence": overall_confidence,
            "probabilities": {
                "home_win": home_win_weight,
                "draw": draw_weight,
                "away_win": away_win_weight
            },
            "analysis": analysis_details,
            "bet_recommendation": bet_recommendation,
            "data_quality": {
                "home_matches": home_stats.matches_played,
                "away_matches": away_stats.matches_played,
                "h2h_matches": len(h2h_matches)
            }
        }
    
    def _calculate_team_form(self, stats: TeamStats) -> float:
        """Calculate overall team form score (0-1)"""
        if stats.matches_played == 0:
            return 0.5
        
        # Weighted scoring based on multiple factors
        win_rate = stats.win_rate
        goal_ratio = stats.goals_for / max(stats.goals_against, 1)
        goal_difference_per_game = stats.goal_difference / stats.matches_played
        
        # Normalize goal ratio (typical range 0.5-2.0)
        normalized_goal_ratio = min(max(goal_ratio - 0.5, 0) / 1.5, 1.0)
        
        # Normalize goal difference per game (typical range -2 to +2)
        normalized_gd = min(max(goal_difference_per_game + 2, 0) / 4, 1.0)
        
        # Combined form score
        form_score = (0.6 * win_rate + 0.25 * normalized_goal_ratio + 0.15 * normalized_gd)
        
        return min(max(form_score, 0.0), 1.0)
    
    def _analyze_head_to_head(self, matches: List[Match], home_team: str, away_team: str) -> Dict[str, Any]:
        """Analyze head-to-head match history"""
        if not matches:
            return {"home_advantage": 0, "away_advantage": 0, "draw_tendency": 0, "summary": "No H2H data"}
        
        home_wins = 0
        away_wins = 0
        draws = 0
        
        for match in matches:
            if match.home_team == home_team:
                if match.result == "1":
                    home_wins += 1
                elif match.result == "2":
                    away_wins += 1
                else:
                    draws += 1
            else:  # match.away_team == home_team
                if match.result == "2":
                    home_wins += 1
                elif match.result == "1":
                    away_wins += 1
                else:
                    draws += 1
        
        total_matches = len(matches)
        home_rate = home_wins / total_matches
        away_rate = away_wins / total_matches
        draw_rate = draws / total_matches
        
        return {
            "home_advantage": home_rate,
            "away_advantage": away_rate,
            "draw_tendency": draw_rate,
            "summary": f"{home_wins}W-{draws}D-{away_wins}L in last {total_matches} meetings"
        }
    
    def _get_recent_form(self, team: str, matches_count: int = 10) -> Optional[float]:
        """Get recent form for a team"""
        try:
            recent_matches = self.data_manager.get_recent_matches(100)  # Get more to filter
            
            # Filter matches for this team
            team_matches = [
                m for m in recent_matches 
                if m.home_team == team or m.away_team == team
            ][:matches_count]
            
            if len(team_matches) < 3:
                return None
            
            points = 0
            for match in team_matches:
                if match.home_team == team:
                    if match.result == "1":
                        points += 3
                    elif match.result == "X":
                        points += 1
                else:  # away team
                    if match.result == "2":
                        points += 3
                    elif match.result == "X":
                        points += 1
            
            # Return points per game ratio (max 3 points per game)
            return points / (len(team_matches) * 3)
            
        except Exception as e:
            logger.error(f"Error getting recent form for {team}: {e}")
            return None
    
    def _generate_bet_recommendation(self, predictions: Dict[str, float], confidence: float) -> Dict[str, Any]:
        """Generate betting recommendation based on prediction"""
        
        max_outcome = max(predictions, key=predictions.get)
        max_prob = predictions[max_outcome]
        
        # Only recommend if confidence is high enough
        if confidence < 0.6:
            return {
                "recommended": False,
                "reason": "Low confidence prediction",
                "suggestion": "Wait for more data or skip this match"
            }
        
        # Strong prediction threshold
        if max_prob > 0.6 and confidence > 0.75:
            outcome_names = {"1": "Home Win", "X": "Draw", "2": "Away Win"}
            return {
                "recommended": True,
                "bet_type": outcome_names[max_outcome],
                "confidence_level": "High" if confidence > 0.85 else "Medium",
                "suggestion": f"Strong prediction for {outcome_names[max_outcome]}"
            }
        
        return {
            "recommended": False,
            "reason": "Prediction not strong enough for betting",
            "suggestion": "Consider smaller stake or wait for clearer pattern"
        }
    
    def get_top_predictions(self, limit: int = 5) -> List[Dict[str, Any]]:
        """Get top predictions for available teams"""
        try:
            teams = self.data_manager.get_all_teams()
            
            if len(teams) < 2:
                return []
            
            predictions = []
            
            # Generate predictions for team combinations
            for i, home_team in enumerate(teams[:limit*2]):  # Limit iterations
                for away_team in teams[i+1:i+3]:  # Limit away teams per home team
                    if home_team != away_team:
                        prediction = self.predict_match(home_team, away_team)
                        if prediction.get('confidence', 0) > 0.6:
                            prediction['match'] = f"{home_team} vs {away_team}"
                            predictions.append(prediction)
            
            # Sort by confidence and return top predictions
            predictions.sort(key=lambda x: x.get('confidence', 0), reverse=True)
            return predictions[:limit]
            
        except Exception as e:
            logger.error(f"Error getting top predictions: {e}")
            return []
    
    def get_team_analysis(self, team_name: str) -> Dict[str, Any]:
        """Get detailed analysis for a specific team"""
        try:
            stats = self.data_manager.get_team_stats(team_name)
            if not stats:
                return {"error": f"No data found for team: {team_name}"}
            
            recent_form = self._get_recent_form(team_name, 10)
            overall_form = self._calculate_team_form(stats)
            
            return {
                "team_name": team_name,
                "overall_stats": {
                    "matches_played": stats.matches_played,
                    "wins": stats.wins,
                    "draws": stats.draws,
                    "losses": stats.losses,
                    "win_rate": f"{stats.win_rate:.1%}",
                    "goals_for": stats.goals_for,
                    "goals_against": stats.goals_against,
                    "goal_difference": stats.goal_difference
                },
                "form_analysis": {
                    "overall_form": f"{overall_form:.2f}/1.00",
                    "recent_form": f"{recent_form:.2f}/1.00" if recent_form else "Insufficient data",
                    "form_rating": self._get_form_rating(overall_form)
                },
                "key_metrics": {
                    "goals_per_game": f"{stats.goals_for / max(stats.matches_played, 1):.1f}",
                    "goals_conceded_per_game": f"{stats.goals_against / max(stats.matches_played, 1):.1f}",
                    "clean_sheets": "N/A",  # Would need additional data tracking
                    "scoring_consistency": "N/A"  # Would need match-by-match analysis
                }
            }
            
        except Exception as e:
            logger.error(f"Error analyzing team {team_name}: {e}")
            return {"error": str(e)}
    
    def _get_form_rating(self, form_score: float) -> str:
        """Convert form score to rating"""
        if form_score >= 0.8:
            return "Excellent ⭐⭐⭐⭐⭐"
        elif form_score >= 0.6:
            return "Good ⭐⭐⭐⭐"
        elif form_score >= 0.4:
            return "Average ⭐⭐⭐"
        elif form_score >= 0.2:
            return "Poor ⭐⭐"
        else:
            return "Very Poor ⭐"
