# Virtual Football Prediction Bot

## Overview

A Telegram bot that provides predictions for virtual football matches by connecting to SportyBet's WebSocket API. The system analyzes historical match data and team statistics to generate predictions with confidence scores for upcoming virtual football games.

## System Architecture

The application follows a modular architecture with clear separation of concerns:

### Core Components
- **Main Application Controller** (`main.py`): Coordinates all components and manages application lifecycle
- **Telegram Bot Interface** (`bot/telegram_bot.py`): Handles user interactions via Telegram
- **WebSocket Client** (`websocket/sportybet_client.py`): Real-time data collection from SportyBet
- **Prediction Engine** (`prediction/analyzer.py`): Statistical analysis and match outcome predictions
- **Data Management** (`data/data_manager.py`): In-memory data storage with file persistence
- **Configuration Management** (`config/settings.py`): Centralized settings and environment variables

### Threading Model
- Main thread: Telegram bot polling
- Background thread: WebSocket client for continuous data collection
- Asynchronous operations: Telegram bot handlers and message processing

## Key Components

### Data Models
- **Match**: Stores match results with teams, scores, timestamps, and outcomes
- **TeamStats**: Aggregated statistics including win rates, goals, and performance metrics

### Prediction Algorithm
- Team performance analysis based on recent matches
- Head-to-head historical comparisons
- Home advantage calculations
- Confidence scoring based on data availability and consistency

### Bot Commands
- `/start`: Welcome message and bot introduction
- `/predict`: Get predictions for upcoming matches
- `/stats`: View team statistics and performance data
- Admin commands for data management and bot monitoring

## Data Flow

1. **Data Collection**: WebSocket client continuously receives match data from SportyBet
2. **Data Processing**: Match results are parsed and stored in the data manager
3. **Statistics Calculation**: Team statistics are updated in real-time
4. **Prediction Generation**: Analyzer processes historical data to generate predictions
5. **User Interaction**: Telegram bot serves predictions and statistics to users

## External Dependencies

### Core Libraries
- `python-telegram-bot`: Telegram Bot API integration
- `websocket-client`: WebSocket communication with SportyBet
- `asyncio`: Asynchronous programming support

### Data Source
- **SportyBet WebSocket API**: Real-time virtual football match data
- URL: `wss://wsapi.sportybet.com/websocket`

### Environment Variables
- `TELEGRAM_BOT_TOKEN`: Bot authentication token
- `SPORTYBET_WS_URL`: WebSocket endpoint (optional override)
- `ADMIN_USER_IDS`: Comma-separated list of admin user IDs
- `LOG_LEVEL`: Logging verbosity level

## Deployment Strategy

### Replit Deployment
- **Runtime**: Python 3.11 with Nix package management
- **Dependencies**: Managed via `pyproject.toml` and `uv.lock`
- **Process**: Single process with multi-threading
- **Persistence**: File-based storage in `data_storage/` directory

### Startup Sequence
1. Install dependencies (`python-telegram-bot`, `websocket-client`, `asyncio`)
2. Initialize configuration and logging
3. Start WebSocket client in background thread
4. Launch Telegram bot with polling
5. Begin serving user requests

### Data Persistence
- JSON-based file storage for match history and statistics
- Automatic directory creation and file management
- Thread-safe operations for concurrent access

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

**June 23, 2025 - Bot Fully Operational**
- Fixed WebSocket client to handle Socket.IO protocol from SportyBet
- Resolved async event loop conflicts between WebSocket and Telegram bot
- Created simplified main entry point (simple_main.py) that works reliably
- Fixed TeamStats data serialization issues
- Generated 100 sample matches with 20 teams for testing
- Verified prediction system works with multiple statistical factors
- Bot successfully connects to both SportyBet WebSocket and Telegram API

**Current Status:**
- WebSocket: Connected to SportyBet and receiving data
- Telegram Bot: Running and responding to commands
- Database: 100 matches stored with team statistics
- Predictions: Working with confidence scoring and detailed analysis

## Changelog

- June 23, 2025: Initial setup and full implementation
- June 23, 2025: Bot deployment successful with all core features working