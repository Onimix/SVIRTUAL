"""
Telegram bot for virtual football predictions
"""

import asyncio
import re
from datetime import datetime
from typing import List, Dict, Any
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler, 
    ContextTypes, MessageHandler, filters
)
from telegram.constants import ParseMode
from utils.logger import setup_logger
from config.settings import Config
from data.data_manager import DataManager
from prediction.analyzer import PredictionAnalyzer
from ws_client.sportybet_client import SportyBetWebSocketClient

logger = setup_logger(__name__)

class TelegramBot:
    """Telegram bot for virtual football predictions"""
    
    def __init__(self):
        self.config = Config()
        self.data_manager = DataManager()
        self.analyzer = PredictionAnalyzer()
        self.application = None
        
        # Validate configuration
        self.config.validate()
        
    async def start(self):
        """Start the Telegram bot"""
        try:
            logger.info("🤖 Initializing Telegram bot...")
            
            # Create application
            self.application = Application.builder().token(self.config.TELEGRAM_BOT_TOKEN).build()
            
            # Add command handlers
            self._add_handlers()
            
            # Start the bot with polling
            logger.info("🚀 Starting Telegram bot...")
            await self.application.run_polling(
                allowed_updates=Update.ALL_TYPES,
                drop_pending_updates=True
            )
            
        except Exception as e:
            logger.error(f"❌ Error starting Telegram bot: {e}")
            raise
    
    async def stop(self):
        """Stop the Telegram bot"""
        if self.application:
            logger.info("🛑 Stopping Telegram bot...")
            await self.application.stop()
            
    def _add_handlers(self):
        """Add command and callback handlers"""
        if not self.application:
            return
            
        # Command handlers
        self.application.add_handler(CommandHandler("start", self._start_command))
        self.application.add_handler(CommandHandler("help", self._help_command))
        self.application.add_handler(CommandHandler("predict", self._predict_command))
        self.application.add_handler(CommandHandler("predict_multi", self._predict_multi_command))
        self.application.add_handler(CommandHandler("stats", self._stats_command))
        self.application.add_handler(CommandHandler("teams", self._teams_command))
        self.application.add_handler(CommandHandler("top", self._top_predictions_command))
        self.application.add_handler(CommandHandler("analyze", self._analyze_team_command))
        self.application.add_handler(CommandHandler("status", self._status_command))
        
        # Callback query handler for inline keyboards
        self.application.add_handler(CallbackQueryHandler(self._handle_callback))
        
        # Message handler for team selection
        self.application.add_handler(
            MessageHandler(filters.TEXT & ~filters.COMMAND, self._handle_message)
        )
    
    async def _start_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /start command"""
        welcome_message = """
🏆 **Virtual Football Prediction Bot** ⚽

Welcome to the most advanced virtual football prediction system! 
I analyze SportyBet virtual football matches and provide statistical predictions.

🎯 **Available Commands:**
/predict - Predict a single match
/predict_multi - Predict multiple matches at once
/stats - View database statistics
/teams - List all available teams
/top - Get top predictions
/analyze - Analyze a specific team
/status - Check bot status
/help - Show detailed help

📊 **How it works:**
• I collect real-time match results from SportyBet
• Statistical analysis of team performance
• Head-to-head history analysis
• Recent form evaluation
• Confidence-based predictions

Let's start predicting! Use /predict to get your first prediction.
        """
        
        # Create inline keyboard
        keyboard = [
            [
                InlineKeyboardButton("🎯 Quick Predict", callback_data="quick_predict"),
                InlineKeyboardButton("📊 Top Predictions", callback_data="top_predictions")
            ],
            [
                InlineKeyboardButton("📈 Statistics", callback_data="stats"),
                InlineKeyboardButton("❓ Help", callback_data="help")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            welcome_message,
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=reply_markup
        )
    
    async def _help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /help command"""
        help_message = """
📖 **Detailed Command Guide**

🎯 **Prediction Commands:**
• `/predict Team1 vs Team2` - Predict single match
  Example: `/predict Arsenal vs Chelsea`

• `/predict_multi` - Predict multiple matches
  Example: `/predict_multi Arsenal vs Chelsea, Madrid vs Barca`

📊 **Analysis Commands:**
• `/analyze TeamName` - Detailed team analysis
  Example: `/analyze Arsenal`

• `/top` - Get top 5 confident predictions
• `/teams` - List all teams with data
• `/stats` - Database statistics

🔧 **System Commands:**
• `/status` - Bot and connection status
• `/help` - Show this help message

💡 **Tips for Best Results:**
• Use exact team names (case-insensitive)
• Predictions improve with more historical data
• Higher confidence = more reliable prediction
• Check team analysis before betting

⚠️ **Important Notes:**
• Predictions are statistical analysis, not guarantees
• Always gamble responsibly
• Use predictions as guidance, not absolute truth

🎯 **Prediction Accuracy:**
Our algorithm considers:
• Team form and statistics
• Head-to-head history  
• Recent performance trends
• Home/away factors
• Goal scoring patterns

Ready to start? Try `/predict Arsenal vs Chelsea`!
        """
        
        await update.message.reply_text(help_message, parse_mode=ParseMode.MARKDOWN)
    
    async def _predict_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /predict command"""
        try:
            # Extract team names from command
            if not context.args:
                await update.message.reply_text(
                    "⚠️ **Usage:** `/predict Team1 vs Team2`\n"
                    "**Example:** `/predict Arsenal vs Chelsea`\n\n"
                    "Use `/teams` to see available teams.",
                    parse_mode=ParseMode.MARKDOWN
                )
                return
            
            # Join all arguments and parse
            match_text = " ".join(context.args)
            teams = self._parse_match_teams(match_text)
            
            if not teams:
                await update.message.reply_text(
                    "❌ **Invalid format!**\n\n"
                    "Please use: `/predict Team1 vs Team2`\n"
                    "**Example:** `/predict Arsenal vs Chelsea`",
                    parse_mode=ParseMode.MARKDOWN
                )
                return
            
            home_team, away_team = teams
            
            # Show processing message
            processing_msg = await update.message.reply_text(
                f"🔍 **Analyzing match...**\n"
                f"⚽ {home_team} vs {away_team}\n"
                f"📊 Processing statistical data...",
                parse_mode=ParseMode.MARKDOWN
            )
            
            # Get prediction
            prediction = self.analyzer.predict_match(home_team, away_team)
            
            # Format and send result
            result_message = self._format_prediction_result(prediction, home_team, away_team)
            
            # Edit the processing message with results
            await processing_msg.edit_text(result_message, parse_mode=ParseMode.MARKDOWN)
            
        except Exception as e:
            logger.error(f"Error in predict command: {e}")
            await update.message.reply_text(
                "❌ **Error processing prediction**\n"
                f"Please try again or contact support.\n\n"
                f"Error: {str(e)[:100]}...",
                parse_mode=ParseMode.MARKDOWN
            )
    
    async def _predict_multi_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /predict_multi command"""
        try:
            if not context.args:
                await update.message.reply_text(
                    "⚠️ **Usage:** `/predict_multi Team1 vs Team2, Team3 vs Team4`\n"
                    "**Example:** `/predict_multi Arsenal vs Chelsea, Madrid vs Barca`\n\n"
                    f"Maximum {self.config.MAX_PREDICTIONS_PER_COMMAND} matches per command.",
                    parse_mode=ParseMode.MARKDOWN
                )
                return
            
            # Parse multiple matches
            matches_text = " ".join(context.args)
            match_pairs = self._parse_multiple_matches(matches_text)
            
            if not match_pairs:
                await update.message.reply_text(
                    "❌ **Invalid format!**\n\n"
                    "Please use: `/predict_multi Team1 vs Team2, Team3 vs Team4`\n"
                    "Separate matches with commas.",
                    parse_mode=ParseMode.MARKDOWN
                )
                return
            
            if len(match_pairs) > self.config.MAX_PREDICTIONS_PER_COMMAND:
                await update.message.reply_text(
                    f"⚠️ **Too many matches!**\n"
                    f"Maximum {self.config.MAX_PREDICTIONS_PER_COMMAND} matches per command.\n"
                    f"You requested {len(match_pairs)} matches.",
                    parse_mode=ParseMode.MARKDOWN
                )
                return
            
            # Show processing message
            processing_msg = await update.message.reply_text(
                f"🔍 **Analyzing {len(match_pairs)} matches...**\n"
                f"📊 Processing statistical data...\n"
                f"⏳ This may take a few seconds...",
                parse_mode=ParseMode.MARKDOWN
            )
            
            # Get predictions for all matches
            predictions = self.analyzer.predict_multiple_matches(match_pairs)
            
            # Format results
            result_message = self._format_multiple_predictions(predictions)
            
            # Edit the processing message with results
            await processing_msg.edit_text(result_message, parse_mode=ParseMode.MARKDOWN)
            
        except Exception as e:
            logger.error(f"Error in predict_multi command: {e}")
            await update.message.reply_text(
                "❌ **Error processing multiple predictions**\n"
                f"Please try again or contact support.\n\n"
                f"Error: {str(e)[:100]}...",
                parse_mode=ParseMode.MARKDOWN
            )
    
    async def _stats_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /stats command"""
        try:
            # Get database statistics
            db_stats = self.data_manager.get_database_stats()
            
            # Get recent matches
            recent_matches = self.data_manager.get_recent_matches(10)
            
            stats_message = f"""
📊 **Database Statistics**

📈 **Overall Data:**
• Total Matches: {db_stats['total_matches']}
• Total Teams: {db_stats['total_teams']}
• Oldest Match: {db_stats['oldest_match'][:10] if db_stats['oldest_match'] != 'No matches' else 'No matches'}
• Latest Match: {db_stats['newest_match'][:10] if db_stats['newest_match'] != 'No matches' else 'No matches'}

⚽ **Recent Matches ({len(recent_matches)}):**
"""
            
            if recent_matches:
                for match in recent_matches[:5]:
                    result_emoji = {"1": "🏆", "X": "🤝", "2": "🏆"}
                    stats_message += f"• {match.home_team} {match.home_score}-{match.away_score} {match.away_team} {result_emoji.get(match.result, '⚽')}\n"
                
                if len(recent_matches) > 5:
                    stats_message += f"• ... and {len(recent_matches) - 5} more matches\n"
            else:
                stats_message += "• No recent matches available\n"
            
            stats_message += f"""
🎯 **Prediction Quality:**
• Minimum matches for prediction: {self.config.MIN_MATCHES_FOR_PREDICTION}
• Confidence threshold: {self.config.CONFIDENCE_THRESHOLD:.0%}
• Data quality: {'Excellent' if db_stats['total_matches'] > 100 else 'Good' if db_stats['total_matches'] > 50 else 'Building...'}

💡 **Tips:**
• More data = better predictions
• Check team analysis before betting
• Use high-confidence predictions only
            """
            
            # Create inline keyboard for additional actions
            keyboard = [
                [
                    InlineKeyboardButton("📋 View Teams", callback_data="teams"),
                    InlineKeyboardButton("🎯 Top Predictions", callback_data="top_predictions")
                ]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await update.message.reply_text(
                stats_message,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=reply_markup
            )
            
        except Exception as e:
            logger.error(f"Error in stats command: {e}")
            await update.message.reply_text(
                "❌ **Error retrieving statistics**\n"
                "Please try again later.",
                parse_mode=ParseMode.MARKDOWN
            )
    
    async def _teams_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /teams command"""
        try:
            teams = self.data_manager.get_all_teams()
            
            if not teams:
                await update.message.reply_text(
                    "📋 **No teams available yet**\n\n"
                    "The bot is still collecting data from SportyBet.\n"
                    "Please check back in a few minutes!",
                    parse_mode=ParseMode.MARKDOWN
                )
                return
            
            # Sort teams alphabetically
            teams.sort()
            
            # Create teams message with statistics
            teams_message = f"📋 **Available Teams ({len(teams)})**\n\n"
            
            for i, team in enumerate(teams[:20], 1):  # Limit to 20 teams per message
                team_stats = self.data_manager.get_team_stats(team)
                if team_stats:
                    win_rate = f"{team_stats.win_rate:.0%}"
                    matches = team_stats.matches_played
                    teams_message += f"{i}. **{team}** - {matches} matches, {win_rate} wins\n"
                else:
                    teams_message += f"{i}. **{team}**\n"
            
            if len(teams) > 20:
                teams_message += f"\n... and {len(teams) - 20} more teams\n"
            
            teams_message += f"""
💡 **Usage:**
• `/predict TeamName1 vs TeamName2`
• `/analyze TeamName`
• Team names are case-insensitive
            """
            
            await update.message.reply_text(teams_message, parse_mode=ParseMode.MARKDOWN)
            
        except Exception as e:
            logger.error(f"Error in teams command: {e}")
            await update.message.reply_text(
                "❌ **Error retrieving teams**\n"
                "Please try again later.",
                parse_mode=ParseMode.MARKDOWN
            )
    
    async def _top_predictions_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /top command"""
        try:
            # Show processing message
            processing_msg = await update.message.reply_text(
                "🔍 **Finding top predictions...**\n"
                "📊 Analyzing all team combinations...",
                parse_mode=ParseMode.MARKDOWN
            )
            
            # Get top predictions
            top_predictions = self.analyzer.get_top_predictions(5)
            
            if not top_predictions:
                await processing_msg.edit_text(
                    "🎯 **No High-Confidence Predictions Available**\n\n"
                    "Reasons this might happen:\n"
                    "• Not enough historical data yet\n"
                    "• All predictions below confidence threshold\n"
                    "• Still collecting match results\n\n"
                    "💡 Try again in a few minutes or use `/predict` for specific matches.",
                    parse_mode=ParseMode.MARKDOWN
                )
                return
            
            # Format top predictions
            result_message = "🎯 **Top Predictions** ⭐\n\n"
            
            for i, pred in enumerate(top_predictions, 1):
                confidence_emoji = "🔥" if pred['confidence'] > 0.8 else "✅" if pred['confidence'] > 0.7 else "📊"
                outcome_name = {"1": "Home Win", "X": "Draw", "2": "Away Win"}[pred['prediction']]
                
                result_message += f"{confidence_emoji} **#{i}: {pred['match']}**\n"
                result_message += f"🎯 Prediction: **{outcome_name}**\n"
                result_message += f"📊 Confidence: **{pred['confidence']:.0%}**\n"
                
                if pred.get('bet_recommendation', {}).get('recommended'):
                    result_message += f"💰 Recommended: {pred['bet_recommendation']['suggestion']}\n"
                
                result_message += "\n"
            
            result_message += """
⚠️ **Disclaimer:**
• These are statistical predictions, not guarantees
• Always gamble responsibly
• Use as guidance only, not absolute truth

💡 Use `/analyze TeamName` for detailed team analysis!
            """
            
            await processing_msg.edit_text(result_message, parse_mode=ParseMode.MARKDOWN)
            
        except Exception as e:
            logger.error(f"Error in top predictions command: {e}")
            await update.message.reply_text(
                "❌ **Error getting top predictions**\n"
                "Please try again later.",
                parse_mode=ParseMode.MARKDOWN
            )
    
    async def _analyze_team_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /analyze command"""
        try:
            if not context.args:
                await update.message.reply_text(
                    "⚠️ **Usage:** `/analyze TeamName`\n"
                    "**Example:** `/analyze Arsenal`\n\n"
                    "Use `/teams` to see available teams.",
                    parse_mode=ParseMode.MARKDOWN
                )
                return
            
            team_name = " ".join(context.args)
            
            # Show processing message
            processing_msg = await update.message.reply_text(
                f"📊 **Analyzing {team_name}...**\n"
                "🔍 Gathering statistical data...",
                parse_mode=ParseMode.MARKDOWN
            )
            
            # Get team analysis
            analysis = self.analyzer.get_team_analysis(team_name)
            
            if 'error' in analysis:
                await processing_msg.edit_text(
                    f"❌ **Team Not Found**\n\n"
                    f"No data available for: **{team_name}**\n\n"
                    "💡 Tips:\n"
                    "• Check spelling (team names are case-insensitive)\n"
                    "• Use `/teams` to see available teams\n"
                    "• Wait for more data collection if team is new",
                    parse_mode=ParseMode.MARKDOWN
                )
                return
            
            # Format analysis result
            result_message = self._format_team_analysis(analysis)
            
            await processing_msg.edit_text(result_message, parse_mode=ParseMode.MARKDOWN)
            
        except Exception as e:
            logger.error(f"Error in analyze command: {e}")
            await update.message.reply_text(
                "❌ **Error analyzing team**\n"
                "Please try again later.",
                parse_mode=ParseMode.MARKDOWN
            )
    
    async def _status_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /status command"""
        try:
            # Get system status
            db_stats = self.data_manager.get_database_stats()
            
            # Check if user is admin for detailed status
            user_id = update.effective_user.id
            is_admin = user_id in self.config.ADMIN_USER_IDS
            
            status_message = f"""
🤖 **Bot Status**

📊 **Data Collection:**
• Status: {'🟢 Active' if db_stats['total_matches'] > 0 else '🟡 Starting up'}
• Total Matches: {db_stats['total_matches']}
• Total Teams: {db_stats['total_teams']}
• Last Update: {datetime.now().strftime('%H:%M:%S')}

🎯 **Prediction Engine:**
• Status: 🟢 Operational
• Min. data threshold: {self.config.MIN_MATCHES_FOR_PREDICTION} matches
• Confidence threshold: {self.config.CONFIDENCE_THRESHOLD:.0%}

💡 **Performance:**
• Response time: Fast
• Data quality: {'Excellent' if db_stats['total_matches'] > 100 else 'Good' if db_stats['total_matches'] > 50 else 'Building'}
• Uptime: Online ✅
            """
            
            if is_admin:
                status_message += f"""
🔧 **Admin Info:**
• Bot version: 1.0.0
• Data directory: {self.config.DATA_DIR}
• Log level: INFO
• Memory usage: Normal
                """
            
            await update.message.reply_text(status_message, parse_mode=ParseMode.MARKDOWN)
            
        except Exception as e:
            logger.error(f"Error in status command: {e}")
            await update.message.reply_text(
                "❌ **Error getting status**\n"
                "Please try again later.",
                parse_mode=ParseMode.MARKDOWN
            )
    
    async def _handle_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle inline keyboard callbacks"""
        query = update.callback_query
        await query.answer()
        
        try:
            if query.data == "quick_predict":
                await query.edit_message_text(
                    "🎯 **Quick Predict**\n\n"
                    "Use the command format:\n"
                    "`/predict Team1 vs Team2`\n\n"
                    "**Example:**\n"
                    "`/predict Arsenal vs Chelsea`\n\n"
                    "💡 Use `/teams` to see available teams.",
                    parse_mode=ParseMode.MARKDOWN
                )
            
            elif query.data == "top_predictions":
                await self._handle_top_predictions_callback(query)
            
            elif query.data == "stats":
                await self._handle_stats_callback(query)
            
            elif query.data == "help":
                await self._handle_help_callback(query)
            
            elif query.data == "teams":
                await self._handle_teams_callback(query)
                
        except Exception as e:
            logger.error(f"Error handling callback {query.data}: {e}")
            await query.edit_message_text(
                "❌ **Error processing request**\n"
                "Please try again later.",
                parse_mode=ParseMode.MARKDOWN
            )
    
    async def _handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle regular text messages"""
        # For now, just provide helpful guidance
        message_text = update.message.text.lower()
        
        if any(word in message_text for word in ['predict', 'vs', 'against']):
            await update.message.reply_text(
                "🎯 **Looking for predictions?**\n\n"
                "Use the command format:\n"
                "`/predict Team1 vs Team2`\n\n"
                "**Example:**\n"
                "`/predict Arsenal vs Chelsea`\n\n"
                "💡 Type `/help` for all available commands!",
                parse_mode=ParseMode.MARKDOWN
            )
        elif any(word in message_text for word in ['help', 'how', 'what']):
            await update.message.reply_text(
                "❓ **Need help?**\n\n"
                "Type `/help` for detailed command guide\n"
                "Or `/start` to see the main menu!",
                parse_mode=ParseMode.MARKDOWN
            )
    
    def _parse_match_teams(self, match_text: str) -> tuple:
        """Parse team names from match text"""
        # Remove common separators and normalize
        match_text = match_text.strip()
        
        # Try different patterns
        patterns = [
            r'^(.+?)\s+vs\s+(.+)$',
            r'^(.+?)\s+v\s+(.+)$', 
            r'^(.+?)\s+against\s+(.+)$',
            r'^(.+?)\s+-\s+(.+)$'
        ]
        
        for pattern in patterns:
            match = re.match(pattern, match_text, re.IGNORECASE)
            if match:
                home_team = match.group(1).strip()
                away_team = match.group(2).strip()
                return (home_team, away_team)
        
        return None
    
    def _parse_multiple_matches(self, matches_text: str) -> List[tuple]:
        """Parse multiple matches from text"""
        # Split by comma
        match_strings = [m.strip() for m in matches_text.split(',')]
        
        match_pairs = []
        for match_str in match_strings:
            if match_str:
                teams = self._parse_match_teams(match_str)
                if teams:
                    match_pairs.append(teams)
        
        return match_pairs
    
    def _format_prediction_result(self, prediction: Dict[str, Any], home_team: str, away_team: str) -> str:
        """Format single prediction result"""
        if prediction.get('error'):
            return f"""
❌ **Prediction Error**

⚽ **Match:** {home_team} vs {away_team}
🚫 **Error:** {prediction['error']}

💡 **Possible solutions:**
• Check team name spelling
• Wait for more data collection
• Use `/teams` to see available teams
            """
        
        if not prediction.get('prediction'):
            return f"""
⚠️ **Insufficient Data**

⚽ **Match:** {home_team} vs {away_team}
📊 **Issue:** Not enough historical data for reliable prediction

💡 **What you can do:**
• Wait for more match results
• Try different teams with more history
• Check back later as data improves
            """
        
        # Get prediction details
        pred_outcome = prediction['prediction']
        confidence = prediction['confidence']
        probabilities = prediction['probabilities']
        
        # Outcome names and emojis
        outcome_names = {"1": "Home Win", "X": "Draw", "2": "Away Win"}
        confidence_emoji = "🔥" if confidence > 0.8 else "✅" if confidence > 0.7 else "📊"
        
        result_message = f"""
{confidence_emoji} **Match Prediction**

⚽ **Match:** {home_team} vs {away_team}
🎯 **Prediction:** **{outcome_names[pred_outcome]}**
📊 **Confidence:** **{confidence:.0%}**

📈 **Probabilities:**
🏠 Home Win: {probabilities['home_win']:.0%}
🤝 Draw: {probabilities['draw']:.0%}
✈️ Away Win: {probabilities['away_win']:.0%}
        """
        
        # Add analysis details
        if prediction.get('analysis'):
            result_message += "\n🔍 **Analysis:**\n"
            for detail in prediction['analysis'][:3]:  # Limit to 3 details
                result_message += f"• {detail}\n"
        
        # Add bet recommendation
        bet_rec = prediction.get('bet_recommendation', {})
        if bet_rec.get('recommended'):
            result_message += f"\n💰 **Bet Recommendation:**\n"
            result_message += f"✅ **{bet_rec['suggestion']}**\n"
            result_message += f"🎯 Confidence Level: {bet_rec['confidence_level']}\n"
        else:
            result_message += f"\n⚠️ **Betting:** {bet_rec.get('reason', 'Low confidence')}\n"
        
        # Add data quality info
        data_quality = prediction.get('data_quality', {})
        result_message += f"""
📊 **Data Quality:**
• {home_team}: {data_quality.get('home_matches', 0)} matches
• {away_team}: {data_quality.get('away_matches', 0)} matches
• Head-to-head: {data_quality.get('h2h_matches', 0)} matches

⚠️ **Disclaimer:** Statistical prediction, not a guarantee!
        """
        
        return result_message
    
    def _format_multiple_predictions(self, predictions: List[Dict[str, Any]]) -> str:
        """Format multiple predictions result"""
        if not predictions:
            return """
⚠️ **No Predictions Available**

None of the requested matches have sufficient data for reliable predictions.

💡 **Tips:**
• Check team name spellings
• Try teams with more match history
• Wait for more data collection
            """
        
        result_message = f"🎯 **Multiple Match Predictions** ({len(predictions)})\n\n"
        
        for i, pred in enumerate(predictions, 1):
            if pred.get('error'):
                result_message += f"❌ **{i}. {pred['match']}**\n"
                result_message += f"Error: {pred['error'][:50]}...\n\n"
                continue
            
            if not pred.get('prediction'):
                result_message += f"⚠️ **{i}. {pred['match']}**\n"
                result_message += f"Insufficient data\n\n"
                continue
            
            # Format successful prediction
            outcome_names = {"1": "Home Win", "X": "Draw", "2": "Away Win"}
            confidence_emoji = "🔥" if pred['confidence'] > 0.8 else "✅" if pred['confidence'] > 0.7 else "📊"
            
            result_message += f"{confidence_emoji} **{i}. {pred['match']}**\n"
            result_message += f"🎯 {outcome_names[pred['prediction']]} ({pred['confidence']:.0%})\n"
            
            # Add quick analysis
            if pred.get('bet_recommendation', {}).get('recommended'):
                result_message += f"💰 Recommended bet\n"
            
            result_message += "\n"
        
        result_message += """
💡 **Next Steps:**
• Use `/predict` for detailed single match analysis
• Check `/analyze TeamName` for team insights
• Remember: These are statistical predictions!

⚠️ **Always gamble responsibly!**
        """
        
        return result_message
    
    def _format_team_analysis(self, analysis: Dict[str, Any]) -> str:
        """Format team analysis result"""
        team_name = analysis['team_name']
        stats = analysis['overall_stats']
        form = analysis['form_analysis']
        metrics = analysis['key_metrics']
        
        return f"""
📊 **Team Analysis: {team_name}**

📈 **Overall Statistics:**
• Matches Played: {stats['matches_played']}
• Record: {stats['wins']}W-{stats['draws']}D-{stats['losses']}L
• Win Rate: {stats['win_rate']}
• Goals: {stats['goals_for']} scored, {stats['goals_against']} conceded
• Goal Difference: {stats['goal_difference']:+d}

🔥 **Form Analysis:**
• Overall Form: {form['overall_form']}
• Recent Form: {form['recent_form']}
• Rating: {form['form_rating']}

⚽ **Key Metrics:**
• Goals per game: {metrics['goals_per_game']}
• Goals conceded per game: {metrics['goals_conceded_per_game']}

💡 **Insights:**
• {'Strong attacking team' if float(metrics['goals_per_game']) > 1.5 else 'Average attack'}
• {'Solid defense' if float(metrics['goals_conceded_per_game']) < 1.0 else 'Vulnerable defense'}
• {'Excellent form' if float(form['overall_form'].split('/')[0]) > 0.7 else 'Room for improvement'}

🎯 **For Predictions:**
Use `/predict {team_name} vs OpponentName` to get match predictions!
        """
    
    async def _handle_top_predictions_callback(self, query):
        """Handle top predictions callback"""
        # This would be similar to _top_predictions_command but for callback
        await query.edit_message_text(
            "🔍 **Getting top predictions...**\n"
            "This may take a moment...",
            parse_mode=ParseMode.MARKDOWN
        )
        
        # Get top predictions (simplified for callback)
        top_predictions = self.analyzer.get_top_predictions(3)
        
        if not top_predictions:
            await query.edit_message_text(
                "🎯 **No High-Confidence Predictions**\n\n"
                "Try again later or use specific team predictions!",
                parse_mode=ParseMode.MARKDOWN
            )
            return
        
        message = "🎯 **Top 3 Predictions**\n\n"
        for i, pred in enumerate(top_predictions, 1):
            outcome_names = {"1": "Home Win", "X": "Draw", "2": "Away Win"}
            message += f"{i}. **{pred['match']}**\n"
            message += f"   {outcome_names[pred['prediction']]} ({pred['confidence']:.0%})\n\n"
        
        await query.edit_message_text(message, parse_mode=ParseMode.MARKDOWN)
    
    async def _handle_stats_callback(self, query):
        """Handle stats callback"""
        db_stats = self.data_manager.get_database_stats()
        
        message = f"""
📊 **Quick Stats**

• Total Matches: {db_stats['total_matches']}
• Total Teams: {db_stats['total_teams']}
• Status: {'🟢 Active' if db_stats['total_matches'] > 0 else '🟡 Starting'}

Use `/stats` for detailed statistics!
        """
        
        await query.edit_message_text(message, parse_mode=ParseMode.MARKDOWN)
    
    async def _handle_help_callback(self, query):
        """Handle help callback"""
        help_message = """
❓ **Quick Help**

🎯 **Main Commands:**
• `/predict Team1 vs Team2` - Single prediction
• `/predict_multi` - Multiple predictions  
• `/teams` - Available teams
• `/top` - Best predictions
• `/analyze Team` - Team analysis

💡 **Example:**
`/predict Arsenal vs Chelsea`

Use `/help` for detailed guide!
        """
        
        await query.edit_message_text(help_message, parse_mode=ParseMode.MARKDOWN)
    
    async def _handle_teams_callback(self, query):
        """Handle teams callback"""
        teams = self.data_manager.get_all_teams()
        
        if not teams:
            await query.edit_message_text(
                "📋 **No teams available yet**\n\n"
                "Still collecting data...",
                parse_mode=ParseMode.MARKDOWN
            )
            return
        
        message = f"📋 **Available Teams** ({len(teams)})\n\n"
        message += "\n".join(f"• {team}" for team in sorted(teams)[:10])
        
        if len(teams) > 10:
            message += f"\n... and {len(teams) - 10} more\n"
        
        message += "\nUse `/teams` for full list with stats!"
        
        await query.edit_message_text(message, parse_mode=ParseMode.MARKDOWN)
