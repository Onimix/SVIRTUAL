#!/usr/bin/env python3
"""
SportyBet Virtual Football Prediction Bot
Main entry point for the application
"""

import asyncio
import signal
import sys
import threading
import time
from utils.logger import setup_logger
from bot.telegram_bot import TelegramBot
from ws_client.sportybet_client import SportyBetWebSocketClient
from config.settings import Config

# Setup logging
logger = setup_logger(__name__)

class VirtualFootballBot:
    """Main application class that coordinates all components"""
    
    def __init__(self):
        self.config = Config()
        self.telegram_bot = None
        self.websocket_client = None
        self.running = False
        
    async def start(self):
        """Start the bot and all its components"""
        try:
            logger.info("🚀 Starting Virtual Football Prediction Bot...")
            
            # Initialize WebSocket client
            self.websocket_client = SportyBetWebSocketClient()
            
            # Start WebSocket client in background thread
            websocket_thread = threading.Thread(
                target=self.websocket_client.start,
                daemon=True
            )
            websocket_thread.start()
            
            # Give WebSocket some time to establish connection
            await asyncio.sleep(2)
            
            # Initialize and start Telegram bot
            logger.info("🤖 Starting Telegram bot...")
            self.telegram_bot = TelegramBot()
            self.running = True
            
            # Run the bot (this will block until stopped)
            await self.telegram_bot.start()
            
        except Exception as e:
            logger.error(f"❌ Error starting bot: {e}")
            await self.stop()
            
    async def stop(self):
        """Stop the bot and all its components"""
        logger.info("🛑 Stopping Virtual Football Prediction Bot...")
        self.running = False
        
        if self.websocket_client:
            self.websocket_client.stop()
            
        if self.telegram_bot:
            await self.telegram_bot.stop()
            
        logger.info("✅ Bot stopped successfully")

def signal_handler(signum, frame):
    """Handle system signals for graceful shutdown"""
    logger.info(f"📶 Received signal {signum}, shutting down...")
    sys.exit(0)

async def main():
    """Main function"""
    # Setup signal handlers for graceful shutdown
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    bot = VirtualFootballBot()
    
    try:
        await bot.start()
    except KeyboardInterrupt:
        logger.info("🔌 Received keyboard interrupt")
    except Exception as e:
        logger.error(f"💥 Unexpected error: {e}")
    finally:
        await bot.stop()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("👋 Goodbye!")
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        sys.exit(1)
