"""
Data management for storing and retrieving match results
"""

import json
import os
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from utils.logger import setup_logger

logger = setup_logger(__name__)

@dataclass
class Match:
    """Data class for match information"""
    match_id: str
    home_team: str
    away_team: str
    home_score: int
    away_score: int
    result: str  # "1" for home win, "X" for draw, "2" for away win
    timestamp: str
    league: str = "Virtual Football"
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert match to dictionary"""
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Match':
        """Create match from dictionary"""
        return cls(**data)

@dataclass
class TeamStats:
    """Statistics for a team"""
    team_name: str
    matches_played: int = 0
    wins: int = 0
    draws: int = 0
    losses: int = 0
    goals_for: int = 0
    goals_against: int = 0
    
    @property
    def win_rate(self) -> float:
        """Calculate win rate"""
        return self.wins / max(self.matches_played, 1)
    
    @property
    def goal_difference(self) -> int:
        """Calculate goal difference"""
        return self.goals_for - self.goals_against
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return asdict(self)

class DataManager:
    """Manages data storage and retrieval for matches and statistics"""
    
    def __init__(self, data_dir: str = "data_storage"):
        self.data_dir = data_dir
        self.matches_file = os.path.join(data_dir, "matches.json")
        self.stats_file = os.path.join(data_dir, "stats.json")
        self._lock = threading.Lock()
        
        # Create data directory if it doesn't exist
        os.makedirs(data_dir, exist_ok=True)
        
        # Initialize files if they don't exist
        self._initialize_files()
        
    def _initialize_files(self):
        """Initialize data files if they don't exist"""
        if not os.path.exists(self.matches_file):
            self._save_json(self.matches_file, [])
            
        if not os.path.exists(self.stats_file):
            self._save_json(self.stats_file, {})
    
    def _load_json(self, filepath: str) -> Any:
        """Load JSON data from file"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError) as e:
            logger.error(f"Error loading {filepath}: {e}")
            return [] if 'matches' in filepath else {}
    
    def _save_json(self, filepath: str, data: Any):
        """Save data to JSON file"""
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.error(f"Error saving {filepath}: {e}")
    
    def add_match(self, match: Match) -> bool:
        """
        Add a new match to the database
        
        Args:
            match: Match object to add
            
        Returns:
            True if match was added, False if it already exists
        """
        with self._lock:
            try:
                # Load existing matches
                matches_data = self._load_json(self.matches_file)
                
                # Check if match already exists
                if any(m.get('match_id') == match.match_id for m in matches_data):
                    logger.debug(f"Match {match.match_id} already exists")
                    return False
                
                # Add new match
                matches_data.append(match.to_dict())
                
                # Save updated matches
                self._save_json(self.matches_file, matches_data)
                
                # Update statistics
                self._update_team_stats(match)
                
                logger.info(f"✅ Added match: {match.home_team} vs {match.away_team}")
                return True
                
            except Exception as e:
                logger.error(f"Error adding match: {e}")
                return False
    
    def _update_team_stats(self, match: Match):
        """Update team statistics based on match result"""
        try:
            stats_data = self._load_json(self.stats_file)
            
            # Update home team stats
            if match.home_team in stats_data:
                home_data = stats_data[match.home_team]
                home_stats = TeamStats(
                    team_name=home_data.get("team_name", match.home_team),
                    matches_played=home_data.get("matches_played", 0),
                    wins=home_data.get("wins", 0),
                    draws=home_data.get("draws", 0),
                    losses=home_data.get("losses", 0),
                    goals_for=home_data.get("goals_for", 0),
                    goals_against=home_data.get("goals_against", 0)
                )
            else:
                home_stats = TeamStats(match.home_team)
            
            # Update away team stats
            if match.away_team in stats_data:
                away_data = stats_data[match.away_team]
                away_stats = TeamStats(
                    team_name=away_data.get("team_name", match.away_team),
                    matches_played=away_data.get("matches_played", 0),
                    wins=away_data.get("wins", 0),
                    draws=away_data.get("draws", 0),
                    losses=away_data.get("losses", 0),
                    goals_for=away_data.get("goals_for", 0),
                    goals_against=away_data.get("goals_against", 0)
                )
            else:
                away_stats = TeamStats(match.away_team)
            
            # Update match counts
            home_stats.matches_played += 1
            away_stats.matches_played += 1
            
            # Update goals
            home_stats.goals_for += match.home_score
            home_stats.goals_against += match.away_score
            away_stats.goals_for += match.away_score
            away_stats.goals_against += match.home_score
            
            # Update win/draw/loss records
            if match.result == "1":  # Home win
                home_stats.wins += 1
                away_stats.losses += 1
            elif match.result == "X":  # Draw
                home_stats.draws += 1
                away_stats.draws += 1
            elif match.result == "2":  # Away win
                home_stats.losses += 1
                away_stats.wins += 1
            
            # Save updated stats
            stats_data[match.home_team] = home_stats.to_dict()
            stats_data[match.away_team] = away_stats.to_dict()
            
            self._save_json(self.stats_file, stats_data)
            
        except Exception as e:
            logger.error(f"Error updating team stats: {e}")
    
    def get_recent_matches(self, limit: int = 50) -> List[Match]:
        """Get recent matches"""
        try:
            matches_data = self._load_json(self.matches_file)
            
            # Sort by timestamp (newest first)
            sorted_matches = sorted(
                matches_data,
                key=lambda x: x.get('timestamp', ''),
                reverse=True
            )
            
            # Convert to Match objects and return limited results
            return [Match.from_dict(m) for m in sorted_matches[:limit]]
            
        except Exception as e:
            logger.error(f"Error getting recent matches: {e}")
            return []
    
    def get_team_stats(self, team_name: str) -> Optional[TeamStats]:
        """Get statistics for a specific team"""
        try:
            stats_data = self._load_json(self.stats_file)
            
            if team_name in stats_data:
                team_data = stats_data[team_name]
                return TeamStats(
                    team_name=team_data.get("team_name", team_name),
                    matches_played=team_data.get("matches_played", 0),
                    wins=team_data.get("wins", 0),
                    draws=team_data.get("draws", 0),
                    losses=team_data.get("losses", 0),
                    goals_for=team_data.get("goals_for", 0),
                    goals_against=team_data.get("goals_against", 0)
                )
            
            return None
            
        except Exception as e:
            logger.error(f"Error getting team stats for {team_name}: {e}")
            return None
    
    def get_all_teams(self) -> List[str]:
        """Get list of all teams"""
        try:
            stats_data = self._load_json(self.stats_file)
            return list(stats_data.keys())
        except Exception as e:
            logger.error(f"Error getting all teams: {e}")
            return []
    
    def get_head_to_head(self, team1: str, team2: str, limit: int = 10) -> List[Match]:
        """Get head-to-head matches between two teams"""
        try:
            matches_data = self._load_json(self.matches_file)
            
            # Filter matches between the two teams
            h2h_matches = [
                Match.from_dict(m) for m in matches_data
                if (m.get('home_team') == team1 and m.get('away_team') == team2) or
                   (m.get('home_team') == team2 and m.get('away_team') == team1)
            ]
            
            # Sort by timestamp (newest first)
            h2h_matches.sort(key=lambda x: x.timestamp, reverse=True)
            
            return h2h_matches[:limit]
            
        except Exception as e:
            logger.error(f"Error getting head-to-head for {team1} vs {team2}: {e}")
            return []
    
    def get_database_stats(self) -> Dict[str, Any]:
        """Get overall database statistics"""
        try:
            matches_data = self._load_json(self.matches_file)
            stats_data = self._load_json(self.stats_file)
            
            total_matches = len(matches_data)
            total_teams = len(stats_data)
            
            # Calculate date range
            if matches_data:
                timestamps = [m.get('timestamp', '') for m in matches_data if m.get('timestamp')]
                if timestamps:
                    oldest = min(timestamps)
                    newest = max(timestamps)
                else:
                    oldest = newest = "Unknown"
            else:
                oldest = newest = "No matches"
            
            return {
                "total_matches": total_matches,
                "total_teams": total_teams,
                "oldest_match": oldest,
                "newest_match": newest,
                "data_files": {
                    "matches_file": self.matches_file,
                    "stats_file": self.stats_file
                }
            }
            
        except Exception as e:
            logger.error(f"Error getting database stats: {e}")
            return {}
